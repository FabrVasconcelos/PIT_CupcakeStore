# PIT_CupcakeStore [![Version](https://img.shields.io/badge/Alpha-green)](.)
Trabalho acadêmico do disciplina Projeto Integrador Transdisciplinar em Ciência da Computação II

[![Python](https://img.shields.io/badge/Languages-Python_3.11.4-blue)](https://img.shields.io/badge/Languages-Python-blue)
[![HTML](https://img.shields.io/badge/Languages-HTML-FF5F15)](https://img.shields.io/badge/Languages-HTML-FF5F15)

[![Flask](https://img.shields.io/badge/Framework-Flask_2.3.3-00ffff)](https://img.shields.io/badge/Framework-Flask-00ffff) 
[![Werkzeug](https://img.shields.io/badge/Utility-Werkzeug_2.3.7-FF5F15)](https://img.shields.io/badge/Framework-Werkzeug_2.3.7-FF5F15) 

## Autores
- [Fabrício Vasconcelos](https://github.com/FabrVasconcelos)

## Instalação
- Ver em [Requirements.txt](https://github.com/FabrVasconcelos/PIT_CupcakeStore/blob/main/requirements.txt)
  
## Melhorias
- 07/10/2023 - Meu primeiro commit com a estrutura básica e definição de Framework
